from Unit import Unit

allUnits = [Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
            Unit("Clubber", "Tribal", 70, "Fair"), Unit("Clubber", "Tribal", 70, "Fair"),
]